CREATE DATABASE ambulance_db;
USE ambulance_db;

CREATE TABLE ambulance (
    id INT AUTO_INCREMENT PRIMARY KEY,
    driver_name VARCHAR(50),
    vehicle_no VARCHAR(20),
    status VARCHAR(20),
    location VARCHAR(50)
);

INSERT INTO ambulance (driver_name, vehicle_no, status, location)
VALUES 
('Ravi', 'AP01AB1234', 'available', 'Chennai'),
('Kumar', 'AP02CD5678', 'available', 'Chennai');
