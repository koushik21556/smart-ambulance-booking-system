package com.example.demo.controller;

import com.example.demo.model.Ambulance;
import com.example.demo.service.AmbulanceService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class BookingController {

    @Autowired
    private AmbulanceService service;

    @PostMapping("/book")
    public String bookAmbulance() {
        Ambulance amb = service.getAvailableAmbulance();
        if (amb == null) {
            return "No ambulance available";
        }
        return "Ambulance booked: " + amb.getVehicleNo();
    }

    @GetMapping("/status")
    public String status() {
        return service.checkStatus();
    }
}
