package com.example.demo.service;

import com.example.demo.model.Ambulance;
import com.example.demo.repository.AmbulanceRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class AmbulanceService {

    @Autowired
    private AmbulanceRepository repo;

    public Ambulance getAvailableAmbulance() {
        List<Ambulance> list = repo.findByStatus("available");

        if (list.isEmpty()) return null;

        Ambulance amb = list.get(0);
        amb.setStatus("busy");
        repo.save(amb);

        return amb;
    }

    public String checkStatus() {
        List<Ambulance> list = repo.findByStatus("available");

        if (list.isEmpty()) {
            return "No ambulances available";
        } else {
            return "Ambulances available: " + list.size();
        }
    }
}
