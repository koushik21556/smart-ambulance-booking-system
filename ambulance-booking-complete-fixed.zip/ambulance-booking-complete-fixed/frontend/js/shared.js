/* ============================================
   🚑 SMART AMBULANCE — SHARED UTILITIES v2.0
   Leaflet Maps, Lottie, Simulation Engine
   ============================================ */

// === MOCK DATA ===
const MOCK_AMBULANCES = [
  { id: 'AMB-001', type: 'Emergency', driver: 'Rajesh Kumar', phone: '+91 98765 43210', plate: 'TS 09 AB 1234', status: 'available', lat: 17.385, lng: 78.4867, rating: 4.8 },
  { id: 'AMB-002', type: 'ICU', driver: 'Suresh Reddy', phone: '+91 87654 32109', plate: 'TS 10 CD 5678', status: 'on-trip', lat: 17.395, lng: 78.4767, rating: 4.9 },
  { id: 'AMB-003', type: 'Non-Emergency', driver: 'Venkat Rao', phone: '+91 76543 21098', plate: 'TS 11 EF 9012', status: 'available', lat: 17.375, lng: 78.4967, rating: 4.7 },
  { id: 'AMB-004', type: 'Patient Transport', driver: 'Mahesh Goud', phone: '+91 65432 10987', plate: 'TS 12 GH 3456', status: 'offline', lat: 17.365, lng: 78.5067, rating: 4.5 },
  { id: 'AMB-005', type: 'Emergency', driver: 'Anil Sharma', phone: '+91 54321 09876', plate: 'TS 13 IJ 7890', status: 'available', lat: 17.405, lng: 78.4667, rating: 4.6 },
  { id: 'AMB-006', type: 'ICU', driver: 'Kiran Patel', phone: '+91 43210 98765', plate: 'TS 14 KL 2345', status: 'on-trip', lat: 17.415, lng: 78.4567, rating: 4.8 },
  { id: 'AMB-007', type: 'Emergency', driver: 'Ravi Teja', phone: '+91 98712 34567', plate: 'TS 15 MN 6789', status: 'available', lat: 17.390, lng: 78.4800, rating: 4.9 },
  { id: 'AMB-008', type: 'Non-Emergency', driver: 'Prasad M', phone: '+91 87612 45678', plate: 'TS 16 OP 0123', status: 'available', lat: 17.380, lng: 78.4900, rating: 4.4 },
];

const MOCK_BOOKINGS = [
  { id: 'BK-1001', patient: 'Srinivas G', phone: '+91 99887 76655', type: 'Emergency', pickup: 'Hitech City, Hyderabad', destination: 'Apollo Hospital', ambulance: 'AMB-001', status: 'completed', time: '2026-03-31T08:30:00', amount: 1500, eta: 0 },
  { id: 'BK-1002', patient: 'Lakshmi D', phone: '+91 88776 65544', type: 'ICU', pickup: 'Gachibowli, Hyderabad', destination: 'KIMS Hospital', ambulance: 'AMB-002', status: 'in-transit', time: '2026-03-31T09:15:00', amount: 3500, eta: 8 },
  { id: 'BK-1003', patient: 'Ramesh B', phone: '+91 77665 54433', type: 'Non-Emergency', pickup: 'Madhapur, Hyderabad', destination: 'Yashoda Hospital', ambulance: 'AMB-003', status: 'pending', time: '2026-03-31T09:45:00', amount: 800, eta: 15 },
  { id: 'BK-1004', patient: 'Priya K', phone: '+91 66554 43322', type: 'Emergency', pickup: 'Banjara Hills, Hyderabad', destination: 'Care Hospital', ambulance: null, status: 'pending', time: '2026-03-31T10:00:00', amount: 1200, eta: 20 },
  { id: 'BK-1005', patient: 'Vikram S', phone: '+91 55443 32211', type: 'Patient Transport', pickup: 'Jubilee Hills, Hyderabad', destination: 'Home', ambulance: 'AMB-004', status: 'completed', time: '2026-03-30T14:00:00', amount: 600, eta: 0 },
  { id: 'BK-1006', patient: 'Anitha R', phone: '+91 44332 21100', type: 'Emergency', pickup: 'Kukatpally, Hyderabad', destination: 'Gandhi Hospital', ambulance: 'AMB-005', status: 'completed', time: '2026-03-30T16:30:00', amount: 1800, eta: 0 },
];

const AMBULANCE_TYPES = [
  { type: 'Emergency', icon: '🚨', color: '#ef4444', price: '₹1,200 - ₹2,000', desc: 'For life-threatening emergencies requiring immediate medical attention', features: ['Oxygen Supply', 'Defibrillator', 'First Aid Kit', 'Trained Paramedic'] },
  { type: 'ICU', icon: '🏥', color: '#8b5cf6', price: '₹3,000 - ₹5,000', desc: 'Mobile ICU with advanced life support for critical patients', features: ['Ventilator', 'Cardiac Monitor', 'IV Drip', 'Specialist Doctor'] },
  { type: 'Non-Emergency', icon: '🚑', color: '#3b82f6', price: '₹600 - ₹1,000', desc: 'For stable patients requiring hospital transfer or routine check-ups', features: ['Stretcher', 'Basic First Aid', 'Comfortable Ride', 'Trained Staff'] },
  { type: 'Patient Transport', icon: '🚐', color: '#06d6a0', price: '₹400 - ₹800', desc: 'Non-medical transport for mobility-challenged individuals', features: ['Wheelchair Access', 'AC Vehicle', 'Patient Comfort', 'Friendly Staff'] },
];

const FIRST_AID_RESPONSES = {
  'heart attack': '🫀 **Heart Attack First Aid:**\n1. Call emergency services immediately\n2. Have the person sit down and rest\n3. Give aspirin if not allergic (chew, don\'t swallow)\n4. Loosen tight clothing\n5. Be ready to perform CPR if they become unresponsive',
  'choking': '😮 **Choking First Aid:**\n1. Ask "Are you choking?" - if they can\'t speak, act fast\n2. Stand behind them, wrap arms around waist\n3. Make a fist above the navel\n4. Perform quick upward thrusts (Heimlich maneuver)\n5. Repeat until object is dislodged or help arrives',
  'bleeding': '🩸 **Severe Bleeding First Aid:**\n1. Apply direct pressure with a clean cloth\n2. Keep pressure firm and continuous\n3. Don\'t remove the cloth if soaked - add more on top\n4. Elevate the injured limb if possible\n5. Apply a tourniquet above the wound if bleeding won\'t stop',
  'burn': '🔥 **Burn First Aid:**\n1. Cool the burn under cool running water for 20 minutes\n2. Do NOT use ice, butter, or toothpaste\n3. Remove jewelry and loose clothing near the burn\n4. Cover with a sterile, non-stick bandage\n5. Take ibuprofen for pain. Seek medical help for large burns',
  'fracture': '🦴 **Fracture First Aid:**\n1. Do NOT try to straighten the bone\n2. Immobilize the area - use a makeshift splint\n3. Apply ice wrapped in cloth to reduce swelling\n4. Elevate the injured limb if possible\n5. Seek immediate medical attention',
  'seizure': '⚡ **Seizure First Aid:**\n1. Clear the area of dangerous objects\n2. Place something soft under their head\n3. Do NOT hold them down or put anything in mouth\n4. Time the seizure\n5. Turn them on their side once seizure stops\n6. Call emergency if seizure lasts >5 minutes',
  'default': '🏥 **General First Aid Tips:**\n1. Stay calm and assess the situation\n2. Ensure scene safety before approaching\n3. Call emergency services (108/102)\n4. Don\'t move the patient unless in danger\n5. Keep the patient warm and comfortable\n6. Monitor breathing and be ready for CPR\n\n💡 Type a condition: heart attack, choking, bleeding, burn, fracture, seizure'
};

// === TOAST NOTIFICATION SYSTEM ===
class ToastManager {
  constructor() {
    this.container = null;
    this.init();
  }

  init() {
    this.container = document.createElement('div');
    this.container.className = 'toast-container';
    document.body.appendChild(this.container);
  }

  show(title, message, type = 'info', duration = 4000) {
    const icons = { success: '✅', error: '❌', warning: '⚠️', info: 'ℹ️' };
    const toast = document.createElement('div');
    toast.className = `toast toast-${type}`;
    toast.innerHTML = `
      <span class="toast-icon">${icons[type]}</span>
      <div class="toast-content">
        <div class="toast-title">${title}</div>
        <div class="toast-message">${message}</div>
      </div>
      <button class="toast-close" onclick="this.parentElement.remove()">×</button>
    `;
    this.container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add('toast-exit');
      setTimeout(() => toast.remove(), 300);
    }, duration);
  }

  success(title, msg) { this.show(title, msg, 'success'); }
  error(title, msg) { this.show(title, msg, 'error'); }
  warning(title, msg) { this.show(title, msg, 'warning'); }
  info(title, msg) { this.show(title, msg, 'info'); }
}

// === MODAL MANAGER ===
class ModalManager {
  static open(id) {
    const modal = document.getElementById(id);
    if (modal) {
      modal.classList.add('active');
      document.body.style.overflow = 'hidden';
    }
  }

  static close(id) {
    const modal = document.getElementById(id);
    if (modal) {
      modal.classList.remove('active');
      document.body.style.overflow = '';
    }
  }

  static closeAll() {
    document.querySelectorAll('.modal-backdrop.active').forEach(m => {
      m.classList.remove('active');
    });
    document.body.style.overflow = '';
  }
}

// === UTILITY FUNCTIONS ===
function generateId(prefix = 'ID') {
  return `${prefix}-${Date.now().toString(36).toUpperCase()}${Math.random().toString(36).substring(2, 6).toUpperCase()}`;
}

function formatTime(date) {
  return new Date(date).toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' });
}

function formatDate(date) {
  return new Date(date).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' });
}

function formatDateTime(date) {
  return `${formatDate(date)} ${formatTime(date)}`;
}

function formatCurrency(amount) {
  return new Intl.NumberFormat('en-IN', { style: 'currency', currency: 'INR', maximumFractionDigits: 0 }).format(amount);
}

function timeAgo(date) {
  const seconds = Math.floor((new Date() - new Date(date)) / 1000);
  if (seconds < 60) return 'just now';
  if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
  if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
  return `${Math.floor(seconds / 86400)}d ago`;
}

function randomBetween(min, max) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

// === LOCAL STORAGE HELPERS ===
function saveToStorage(key, data) {
  try {
    localStorage.setItem(key, JSON.stringify(data));
  } catch (e) {
    console.warn('localStorage save failed:', e);
  }
}

function loadFromStorage(key, fallback = null) {
  try {
    const data = localStorage.getItem(key);
    return data ? JSON.parse(data) : fallback;
  } catch (e) {
    return fallback;
  }
}

// === PARTICLES GENERATOR ===
function createParticles(count = 30) {
  const container = document.querySelector('.particles');
  if (!container) return;

  for (let i = 0; i < count; i++) {
    const particle = document.createElement('div');
    particle.className = 'particle';
    particle.style.left = Math.random() * 100 + '%';
    particle.style.animationDuration = (Math.random() * 15 + 10) + 's';
    particle.style.animationDelay = (Math.random() * 10) + 's';
    particle.style.opacity = Math.random() * 0.5 + 0.1;
    container.appendChild(particle);
  }
}

// === RIPPLE EFFECT ===
function addRipple(e) {
  const btn = e.currentTarget;
  const circle = document.createElement('span');
  const diameter = Math.max(btn.clientWidth, btn.clientHeight);
  const radius = diameter / 2;
  circle.style.width = circle.style.height = diameter + 'px';
  circle.style.left = (e.clientX - btn.getBoundingClientRect().left - radius) + 'px';
  circle.style.top = (e.clientY - btn.getBoundingClientRect().top - radius) + 'px';
  circle.className = 'ripple';
  const existing = btn.querySelector('.ripple');
  if (existing) existing.remove();
  btn.appendChild(circle);
}

// === NAVBAR SCROLL EFFECT ===
function initNavScroll() {
  const nav = document.querySelector('.nav-top');
  if (!nav) return;
  window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 20);
  });
}

// === INTERSECTION OBSERVER FOR ANIMATE-IN ===
function initScrollAnimations() {
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('animate-in');
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.scroll-animate').forEach(el => {
    observer.observe(el);
  });
}

// === COUNTER ANIMATION ===
function animateCounter(element, target, duration = 2000) {
  if (!element) return;
  let start = 0;
  const increment = target / (duration / 16);
  const timer = setInterval(() => {
    start += increment;
    if (start >= target) {
      element.textContent = target.toLocaleString();
      clearInterval(timer);
    } else {
      element.textContent = Math.floor(start).toLocaleString();
    }
  }, 16);
}

// === LEAFLET MAP ENGINE ===
const MapEngine = {
  maps: {},
  markers: {},
  simulationIntervals: {},

  // Hyderabad city center
  DEFAULT_CENTER: [17.385, 78.4867],
  DEFAULT_ZOOM: 13,

  // Dark tile layer URL
  TILE_URL: 'https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png',
  TILE_ATTRIBUTION: '&copy; <a href="https://www.openstreetmap.org/copyright">OSM</a> &copy; <a href="https://carto.com/">CARTO</a>',

  // Create a Leaflet map inside a container
  createMap(containerId, options = {}) {
    const container = document.getElementById(containerId);
    if (!container) return null;

    // Clear if map already exists
    if (this.maps[containerId]) {
      this.maps[containerId].remove();
      delete this.maps[containerId];
    }

    const center = options.center || this.DEFAULT_CENTER;
    const zoom = options.zoom || this.DEFAULT_ZOOM;

    const map = L.map(containerId, {
      center,
      zoom,
      zoomControl: true,
      attributionControl: false
    });

    L.tileLayer(this.TILE_URL, {
      attribution: this.TILE_ATTRIBUTION,
      maxZoom: 19
    }).addTo(map);

    this.maps[containerId] = map;
    this.markers[containerId] = [];

    // Fix map display in hidden tabs
    setTimeout(() => map.invalidateSize(), 200);

    return map;
  },

  // Custom ambulance icon
  createAmbulanceIcon(status = 'available') {
    const colors = {
      'available': '#22c55e',
      'on-trip': '#ef4444',
      'offline': '#64748b',
      'en-route': '#f59e0b'
    };
    const color = colors[status] || '#3b82f6';
    return L.divIcon({
      className: 'custom-ambulance-marker',
      html: `<div style="
        font-size: 24px;
        filter: drop-shadow(0 0 8px ${color}80);
        animation: breathe 2s ease-in-out infinite;
        text-align: center;
        line-height: 1;
      ">🚑</div>
      <div style="
        width: 12px; height: 12px;
        background: ${color};
        border-radius: 50%;
        margin: 2px auto 0;
        box-shadow: 0 0 10px ${color};
        animation: dotPulse 1.5s ease-in-out infinite;
      "></div>`,
      iconSize: [40, 40],
      iconAnchor: [20, 20]
    });
  },

  // User location icon
  createUserIcon() {
    return L.divIcon({
      className: 'custom-user-marker',
      html: `<div style="
        width: 16px; height: 16px;
        background: #00b4ff;
        border: 3px solid white;
        border-radius: 50%;
        box-shadow: 0 0 20px rgba(0,180,255,0.6);
        animation: dotPulse 2s ease-in-out infinite;
      "></div>`,
      iconSize: [22, 22],
      iconAnchor: [11, 11]
    });
  },

  // Hospital icon
  createHospitalIcon() {
    return L.divIcon({
      className: 'custom-hospital-marker',
      html: `<div style="font-size: 24px; filter: drop-shadow(0 2px 4px rgba(0,0,0,0.5));">🏥</div>`,
      iconSize: [28, 28],
      iconAnchor: [14, 14]
    });
  },

  // Place ambulance markers on map
  placeAmbulances(containerId, ambulances = MOCK_AMBULANCES) {
    const map = this.maps[containerId];
    if (!map) return;

    // Clear existing markers
    this.markers[containerId]?.forEach(m => map.removeLayer(m));
    this.markers[containerId] = [];

    ambulances.forEach(amb => {
      const marker = L.marker([amb.lat, amb.lng], {
        icon: this.createAmbulanceIcon(amb.status)
      }).addTo(map);

      marker.bindPopup(`
        <div style="min-width:180px;">
          <div style="font-weight:700;font-size:14px;margin-bottom:4px;">${amb.id} — ${amb.driver}</div>
          <div style="font-size:12px;color:#94a3b8;margin-bottom:6px;">${amb.plate} • ${amb.type}</div>
          <div style="display:flex;align-items:center;gap:4px;">
            <span style="width:6px;height:6px;border-radius:50%;background:${amb.status === 'available' ? '#22c55e' : amb.status === 'on-trip' ? '#ef4444' : '#64748b'};"></span>
            <span style="font-size:12px;text-transform:capitalize;">${amb.status.replace('-',' ')}</span>
            <span style="margin-left:auto;font-size:12px;">⭐ ${amb.rating}</span>
          </div>
        </div>
      `);

      this.markers[containerId].push(marker);
    });
  },

  // Simulate ambulance movement
  startSimulation(containerId, ambulances = MOCK_AMBULANCES) {
    this.stopSimulation(containerId);

    const map = this.maps[containerId];
    if (!map) return;

    this.placeAmbulances(containerId, ambulances);

    this.simulationIntervals[containerId] = setInterval(() => {
      this.markers[containerId].forEach((marker, i) => {
        if (ambulances[i] && ambulances[i].status !== 'offline') {
          const pos = marker.getLatLng();
          const newLat = pos.lat + (Math.random() - 0.5) * 0.003;
          const newLng = pos.lng + (Math.random() - 0.5) * 0.003;
          marker.setLatLng([newLat, newLng]);
        }
      });
    }, 3000);
  },

  stopSimulation(containerId) {
    if (this.simulationIntervals[containerId]) {
      clearInterval(this.simulationIntervals[containerId]);
      delete this.simulationIntervals[containerId];
    }
  },

  // Simulate an ambulance moving toward a destination
  simulateRoute(containerId, startLatLng, endLatLng, durationSec = 30) {
    const map = this.maps[containerId];
    if (!map) return;

    // Draw animated polyline
    const latlngs = this.interpolatePath(startLatLng, endLatLng, 20);
    const routeLine = L.polyline([], {
      color: '#2563eb',
      weight: 4,
      opacity: 0.8,
      dashArray: '10, 8',
      className: 'animated-route'
    }).addTo(map);

    // Animate the line drawing
    let lineIndex = 0;
    const lineInterval = setInterval(() => {
      if (lineIndex < latlngs.length) {
        routeLine.addLatLng(latlngs[lineIndex]);
        lineIndex++;
      } else {
        clearInterval(lineInterval);
      }
    }, (durationSec * 1000) / latlngs.length / 2);

    // Moving ambulance marker
    const ambMarker = L.marker(startLatLng, {
      icon: this.createAmbulanceIcon('en-route')
    }).addTo(map);

    let step = 0;
    const moveInterval = setInterval(() => {
      if (step < latlngs.length) {
        ambMarker.setLatLng(latlngs[step]);
        map.panTo(latlngs[step], { animate: true, duration: 0.5 });
        step++;
      } else {
        clearInterval(moveInterval);
      }
    }, (durationSec * 1000) / latlngs.length);

    // User marker
    L.marker(endLatLng, { icon: this.createUserIcon() }).addTo(map);

    // Fit bounds
    map.fitBounds([startLatLng, endLatLng], { padding: [50, 50] });

    return { routeLine, ambMarker, moveInterval, lineInterval };
  },

  // Generate intermediate points
  interpolatePath(start, end, numPoints) {
    const points = [];
    for (let i = 0; i <= numPoints; i++) {
      const t = i / numPoints;
      const lat = start[0] + (end[0] - start[0]) * t + (Math.random() - 0.5) * 0.002;
      const lng = start[1] + (end[1] - start[1]) * t + (Math.random() - 0.5) * 0.002;
      points.push([lat, lng]);
    }
    return points;
  },

  // Heatmap overlay (admin)
  addHeatmapOverlay(containerId, ambulances = MOCK_AMBULANCES) {
    const map = this.maps[containerId];
    if (!map) return;

    ambulances.forEach(amb => {
      const statusClass = amb.status === 'on-trip' ? 'busy' : amb.status === 'available' ? 'available' : 'idle';
      const pulseRadius = amb.status === 'on-trip' ? 40 : 25;

      L.circle([amb.lat, amb.lng], {
        radius: pulseRadius * 20,
        color: 'transparent',
        fillColor: amb.status === 'on-trip' ? '#ef4444' : amb.status === 'available' ? '#22c55e' : '#f59e0b',
        fillOpacity: 0.15,
        className: `heatmap-circle ${statusClass}`
      }).addTo(map);
    });
  }
};

// === SIMULATED MAP FALLBACK (when Leaflet not loaded) ===
function createSimulatedMap(containerId) {
  // If Leaflet is available, use it
  if (typeof L !== 'undefined') {
    const map = MapEngine.createMap(containerId);
    if (map) {
      MapEngine.startSimulation(containerId);
    }
    return;
  }

  // Fallback: CSS-animated map
  const container = document.getElementById(containerId);
  if (!container) return;

  container.innerHTML = `
    <div style="width:100%;height:100%;background:linear-gradient(135deg,#0a1628,#0f2847);display:flex;flex-direction:column;align-items:center;justify-content:center;position:relative;overflow:hidden;">
      <div style="position:absolute;inset:0;opacity:0.1;">
        ${generateMapGrid()}
      </div>
      <div style="position:absolute;width:100%;height:100%;">
        ${generateMapDots()}
      </div>
      <div style="position:relative;z-index:2;text-align:center;">
        <div style="font-size:48px;margin-bottom:8px;animation: breathe 2s ease-in-out infinite;">📍</div>
        <div style="font-size:14px;color:#94a3b8;">Live GPS Tracking</div>
        <div style="font-size:12px;color:#64748b;margin-top:4px;">17.3850° N, 78.4867° E</div>
      </div>
      <div class="ambulance-marker" style="position:absolute;font-size:32px;top:30%;left:20%;animation:ambulanceMove 8s linear infinite;">🚑</div>
      <div class="ambulance-marker" style="position:absolute;font-size:24px;top:60%;left:60%;animation:ambulanceMove 12s linear infinite reverse;">🚑</div>
    </div>
  `;
}

function generateMapGrid() {
  let lines = '';
  for (let i = 0; i < 20; i++) {
    const y = i * 5;
    lines += `<div style="position:absolute;top:${y}%;left:0;right:0;height:1px;background:rgba(37,99,235,0.2);"></div>`;
    lines += `<div style="position:absolute;left:${y}%;top:0;bottom:0;width:1px;background:rgba(37,99,235,0.2);"></div>`;
  }
  return lines;
}

function generateMapDots() {
  let dots = '';
  for (let i = 0; i < 8; i++) {
    const top = 10 + Math.random() * 80;
    const left = 10 + Math.random() * 80;
    const size = 6 + Math.random() * 4;
    const colors = ['#ef4444', '#22c55e', '#3b82f6', '#f59e0b'];
    const color = colors[Math.floor(Math.random() * colors.length)];
    dots += `<div style="position:absolute;top:${top}%;left:${left}%;width:${size}px;height:${size}px;background:${color};border-radius:50%;box-shadow:0 0 10px ${color}80;animation:dotPulse ${1.5 + Math.random()}s ease-in-out infinite;"></div>`;
  }
  return dots;
}

// === DYNAMIC ETA COUNTER ===
class ETACounter {
  constructor(elementId, initialMinutes) {
    this.element = document.getElementById(elementId);
    this.minutes = initialMinutes;
    this.seconds = 0;
    this.interval = null;
  }

  start() {
    if (!this.element) return;
    this.seconds = this.minutes * 60;
    this.render();
    this.interval = setInterval(() => {
      if (this.seconds > 0) {
        this.seconds--;
        // Slightly randomize —sometimes speed up, sometimes slow
        if (Math.random() < 0.1) {
          this.seconds = Math.max(0, this.seconds - randomBetween(0, 5));
        }
        this.render();
      } else {
        clearInterval(this.interval);
        this.element.textContent = '0:00';
      }
    }, 1000);
  }

  render() {
    const m = Math.floor(this.seconds / 60);
    const s = this.seconds % 60;
    this.element.textContent = `${m}:${s.toString().padStart(2, '0')}`;
    // Add animation
    this.element.style.animation = 'none';
    this.element.offsetHeight; // trigger reflow
    this.element.style.animation = 'countUp 0.3s ease-out';
  }

  stop() {
    if (this.interval) clearInterval(this.interval);
  }

  getMinutes() {
    return Math.ceil(this.seconds / 60);
  }
}

// === LOTTIE HELPER ===
const LottieHelper = {
  load(containerId, animationUrl, options = {}) {
    if (typeof lottie === 'undefined') {
      // Fallback: show a nice CSS animation instead
      const container = document.getElementById(containerId);
      if (container) {
        container.innerHTML = `<div style="font-size:80px;animation:breathe 2s ease-in-out infinite;">✅</div>`;
      }
      return null;
    }
    return lottie.loadAnimation({
      container: document.getElementById(containerId),
      renderer: 'svg',
      loop: options.loop !== undefined ? options.loop : false,
      autoplay: options.autoplay !== undefined ? options.autoplay : true,
      path: animationUrl
    });
  }
};

// === SIMULATION ACTIVITY FEED ===
const ActivityFeed = {
  activities: [],
  maxItems: 50,

  generate() {
    const types = [
      { icon: '🚑', text: () => `Ambulance ${MOCK_AMBULANCES[randomBetween(0,7)].id} dispatched to ${['Hitech City','Gachibowli','Madhapur','Banjara Hills'][randomBetween(0,3)]}`, color: '#ef4444' },
      { icon: '✅', text: () => `Booking ${generateId('BK')} completed successfully`, color: '#22c55e' },
      { icon: '📍', text: () => `Driver ${MOCK_AMBULANCES[randomBetween(0,7)].driver} went ${Math.random()>0.5?'online':'offline'}`, color: '#3b82f6' },
      { icon: '🏥', text: () => `Patient arrived at ${['Apollo','KIMS','Care','Yashoda'][randomBetween(0,3)]} Hospital`, color: '#06d6a0' },
      { icon: '⚡', text: () => `SOS alert received from ${['Kukatpally','Jubilee Hills','Secunderabad','Ameerpet'][randomBetween(0,3)]}`, color: '#f59e0b' },
      { icon: '💰', text: () => `Payment of ${formatCurrency(randomBetween(600,4000))} processed`, color: '#8b5cf6' },
    ];
    const t = types[randomBetween(0, types.length - 1)];
    return {
      icon: t.icon,
      text: t.text(),
      color: t.color,
      time: new Date().toISOString(),
      id: generateId('ACT')
    };
  },

  renderToContainer(containerId, count = 10) {
    const container = document.getElementById(containerId);
    if (!container) return;

    // Generate initial items
    for (let i = 0; i < count; i++) {
      this.activities.push(this.generate());
    }

    this.renderList(container);

    // Auto-add new ones
    setInterval(() => {
      const newItem = this.generate();
      this.activities.unshift(newItem);
      if (this.activities.length > this.maxItems) this.activities.pop();
      this.renderList(container);
    }, randomBetween(4000, 8000));
  },

  renderList(container) {
    container.innerHTML = this.activities.map((a, i) => `
      <div class="activity-feed-item ${i === 0 ? 'new' : ''}" style="animation-delay:${i * 0.05}s;">
        <div style="width:32px;height:32px;border-radius:50%;background:${a.color}15;display:flex;align-items:center;justify-content:center;font-size:16px;flex-shrink:0;">${a.icon}</div>
        <div style="flex:1;font-size:13px;color:var(--text-secondary);line-height:1.5;">${a.text}</div>
        <div style="font-size:11px;color:var(--text-muted);white-space:nowrap;">${timeAgo(a.time)}</div>
      </div>
    `).join('');
  }
};

// === INIT COMMON ===
function initCommon() {
  createParticles(25);
  initNavScroll();
  initScrollAnimations();

  // Add ripple to all buttons
  document.querySelectorAll('.btn').forEach(btn => {
    btn.addEventListener('click', addRipple);
  });
}

// Auto-init on DOMContentLoaded
document.addEventListener('DOMContentLoaded', initCommon);
